/// Copyright (c) Microsoft Corporation. 
/// 
/// The contents of this file are subject to the terms of the New BSD License. 
/// You may obtain a copy of the License at http://es5conformm.codeplex.com/license 
/// 
/// Alternatively the contents of this file may be used under the terms of the Microsoft Public License. 
/// You may obtain a copy of the License at http://www.microsoft.com/opensource/licenses.mspx#Ms-PL 

/*
sth: Simple Test Harness
*/
sth.prototype.add = function (t) {
  this.tests.push(t);
}

sth.prototype.run = function () {
  var t      = this.tests;  // the tests collection
  var ut     = undefined;   // a particular unittest
  var res    = false;       // the result of running the unittest
  var prereq = undefined;   // any prerequisite specified by the unittest
  var pres   = true;        // the result of running that prerequite

  for (var i = 0; i < t.length; i++) {
    ut = t[i];

    // if it is a dummytest (its title will be the empty string) skip it.
    if (ut.title === '') {
      continue;
    }

    // if the test specifies a prereq, run that.
    pre = ut.pre;
    pres = true;
    if (pre !== undefined) {
      try {
        pres = pre();
        if (pres !== true) {
          ut.res = 'prereq failed';
        }
      }
      catch (e) {
        pres = false;
        ut.res = 'prereq failed with exception: ' + e.description;
      }
    }

    // if the prereq is met, run the testcase now.
    if (pres === true) {
      try {
        res = ut.theTestcase.call();
        if (res === true) {
          ut.res = 'pass';
          this.totalTestsPassed++;
        }
        else {
          ut.res = 'fail';
        }
      }
      catch (e) {
        ut.res = 'failed with exception: ' + e.description;
      }
    }

    this.totalTestsRun++;
  }
}

sth.prototype.OpenSourceWindow = function (idx) {
  var ut = this.tests[idx];
  var popWnd = window.open("", "", "scrollbars=1, resizable=1");
  var innerHTML = '';

  if (ut.title) {
    innerHTML += '<b>Title</b>';
    innerHTML += '<pre>' + ut.title + ' </pre>';
  }

  innerHTML += '<b>Testcase</b>';
  innerHTML += '<pre>' + ut.theTestcase.toString() + '</pre>';

  if (ut.pre) {
    innerHTML += '<b>Prereq</b>';
    innerHTML += '<pre>' + ut.pre + '</pre>';
  }

  innerHTML += '<b>Path</b>';
  innerHTML += '<pre>' + ut.path + ' </pre>&nbsp';
  popWnd.document.write(innerHTML);
}

sth.prototype.report = function sth_report() {
  this.println('Total tests' + ' : ' + this.totalTestsRun + ' Passed' + ' : ' + this.totalTestsPassed);

  var t = this.tests;
  var ut = undefined;

  for (var i = 0; i < t.length; i++) {
    ut = t[i];

    if (ut.title === '') {
      this.println('');
      continue;
    }

    var href = '<span style="color:blue" onclick="sth.OpenSourceWindow(' + i + ');"> [Source] </span>';

    if (ut.res === 'pass') {
      this.println(ut.title + ' : ' + ut.res + href);
    }
    else {
      this.println(ut.title + ' : ' + '<span style=\"color:red\">' + ut.res + '</span>' + href);
    }
  }

  this.resultsDiv.innerHTML += this.innerHTML;
}

sth.prototype.println = function (s) {
  this.innerHTML += s;
  this.innerHTML += "<BR>";
}

function sth() {
  this.totalTestsRun    = 0;
  this.totalTestsPassed = 0;
  this.tests            = [];
  this.innerHTML        = "";
  this.resultsDiv       = document.createElement("div");
  
  document.body.appendChild(this.resultsDiv);
}

function sth_test(t, d, path, p) {
  this.title       = t;
  this.theTestcase = d;
  this.path        = path;
  this.res         = undefined;
  this.pre         = p;
}


// ----------------------------------------------
// for backwards compat.
// ----------------------------------------------
var sth = new sth();

var aryTestCasePaths;
var testIndex = 0;

function sth_addTest(title, theTestFunction, thePrereq) {
  var t = new sth_test(title, theTestFunction, aryTestCasePaths[testIndex], thePrereq);
  testIndex++;
  sth.add(t);
}

function ConvertToFileUrl(pathStr) {
  return "file:///" + pathStr.replace(/\\/g, "/");
}

function sth_loadtests(aryPaths) {
  aryTestCasePaths = aryPaths;

  for (var i = 0; i < aryPaths.length; i++) {
    var script = document.createElement("script");
    document.body.appendChild(script);
    script.src = ConvertToFileUrl(aryPaths[i]);
  }
}

function sth_run() {
  sth.run();
  sth.report();
}
// ----------------------------------------------


// ----------------------------------------------
// helpers that unittests can use (typically in
// their prereq function).
// ----------------------------------------------
function fnExists(f) {
  if (typeof(f) === "function") {
    return true;
  }
}


function compareArray(aExpected, aActual) {
  if (aActual.length != aExpected.length) {
    return false;
  }

  aExpected.sort();
  aActual.sort();

  var s;
  for (var i = 0; i < aExpected.length; i++) {
    if (aActual[i] != aExpected[i]) {
      return false;
    }
  }
  
  return true;
}