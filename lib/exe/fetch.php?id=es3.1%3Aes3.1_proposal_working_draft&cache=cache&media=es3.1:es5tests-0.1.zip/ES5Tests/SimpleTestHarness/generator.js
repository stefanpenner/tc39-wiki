/// Copyright (c) Microsoft Corporation. 
/// 
/// The contents of this file are subject to the terms of the New BSD License. 
/// You may obtain a copy of the License at http://es5conformm.codeplex.com/license 
/// 
/// Alternatively the contents of this file may be used under the terms of the Microsoft Public License. 
/// You may obtain a copy of the License at http://www.microsoft.com/opensource/licenses.mspx#Ms-PL 

// ===================================================================
// TestCase is the generic base class for a TestGroup and a UnitTest.
//
// A UnitTest is an actual test (a .js file) that gets run.
//
// Zero or more UnitTest are grouped together in a folder; each folder
// is represented as a TestGroup.
// ===================================================================
TestCase.Build = function (path) {
  if (fso.FolderExists(path)) {
    return new TestGroup(path);
  }
  else {
    return new UnitTest(path);
  }
}

function TestCase() {}
// ===================================================================


// ===================================================================
// TestGroup represents a folder containing zero or more TestCases
// ===================================================================
TestGroup.prototype = new TestCase();

TestGroup.prototype.Emit = function (writer) {
  for (var i = 0; i < this.tcList.length; i++) {
    this.tcList[i].Emit(writer)
  }
}

TestGroup.prototype.add = function (tc) {
  this.tcList.push(tc);
}

TestGroup.prototype.BuildTestCase = function (path) {
  var folder = fso.GetFolder(path);
  var subfolderEnumerator = new Enumerator(folder.SubFolders);
  var filesEnumerator     = new Enumerator(folder.Files);

  var flag = false;
  for (;!filesEnumerator.atEnd();filesEnumerator.moveNext()) {
    this.add(new UnitTest(filesEnumerator.item().Path));
    flag = true;
  }

  if (flag === true) {
    this.add(new UnitTest(dummyTestCasePath));
    flag = false;
  }


  for (;!subfolderEnumerator.atEnd();subfolderEnumerator.moveNext()) {
    this.add(new TestGroup(subfolderEnumerator.item().Path));
  }
}

function TestGroup(folderPath) {
  this.path   = folderPath;
  this.tcList = [];

  this.BuildTestCase(folderPath);
}
// ===================================================================


// ===================================================================
// UnitTest represents an actual test that can be run.
// A UnitTest maps to a single .js file.
// ===================================================================
UnitTest.prototype = new TestCase();

UnitTest.prototype.Emit = function (writer) {
  writer.write(this.path);
}

function UnitTest(filePath) {
  this.path = filePath;
}
// ===================================================================


// ===================================================================
// HTMLWriter writes HTML.
// ===================================================================
HTMLWriter.prototype.prologue = function () {
  WScript.echo('<meta http-equiv="X-UA-Compatible" content="IE=8"/>');
  WScript.echo('<html>');
  WScript.echo('<body>');
  WScript.echo('</body>')
  WScript.echo('<script type=\"text/javascript\" src=\"sth.js\"></script>');

  WScript.echo('<script>');
  WScript.echo('var aryPaths = [');
}

HTMLWriter.prototype.write = function (s) {
  var re = /\\/g;
  WScript.echo('"' + s.replace(re, '\\\\') + '"' + ",");
}

HTMLWriter.prototype.epilogue = function () {
  WScript.echo('"' + dummyTestCasePath + '"];')
  WScript.echo('sth_loadtests(aryPaths);');
  WScript.echo('</script>');
  WScript.echo('<script> sth_run(); </script>');
}

function HTMLWriter() {}
// ======================================


var startingFolderPath = "..\\TestCases";
var fso = new ActiveXObject("Scripting.FileSystemObject");
var dummyTestCasePath = fso.GetFolder(".").Path.replace(/\\/g, "\\\\") + "\\\\dummyTestCase.js";

var tc = TestCase.Build(startingFolderPath);

var w = new HTMLWriter();
w.prologue();
tc.Emit(w);
w.epilogue();