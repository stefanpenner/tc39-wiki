/// Copyright (c) Microsoft Corporation. 
/// 
/// The contents of this file are subject to the terms of the New BSD License. 
/// You may obtain a copy of the License at http://es5conformm.codeplex.com/license 
/// 
/// Alternatively the contents of this file may be used under the terms of the Microsoft Public License. 
/// You may obtain a copy of the License at http://www.microsoft.com/opensource/licenses.mspx#Ms-PL 

var testName = "with introduces scope - block-local function expression not visible outside";

function testcase() {
  var o = {};

  with (o) {
    var foo = function () { return 42; }
  }
  
  try {
    foo;
  }
  catch (e) {
    // actually, we need to have thrown a ReferenceError exception.
    // However, in JScript we have thrown a TypeError exception.
    // But that is a separate test.
    return true;
  }
}

sth_addTest(testName, testcase);