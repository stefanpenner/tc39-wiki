/// Copyright (c) Microsoft Corporation. 
/// 
/// The contents of this file are subject to the terms of the New BSD License. 
/// You may obtain a copy of the License at http://es5conformm.codeplex.com/license 
/// 
/// Alternatively the contents of this file may be used under the terms of the Microsoft Public License. 
/// You may obtain a copy of the License at http://www.microsoft.com/opensource/licenses.mspx#Ms-PL 

var testName = "with introduces scope - varname lookup finds property (breaking change from ES3)";

function testcase() {
  var a = 1;

  function foo() {
    var o = {a : 2};

    with (o) {
      var a = 3;
    }

    if (a === 1 && o.a === 2) {
      return true;
    }
  }

  if (foo() === true && a === 1) {
    return true;
  }
}

sth_addTest(testName, testcase);