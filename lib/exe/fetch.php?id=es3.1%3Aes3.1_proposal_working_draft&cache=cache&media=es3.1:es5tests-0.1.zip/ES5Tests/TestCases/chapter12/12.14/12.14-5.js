/// Copyright (c) Microsoft Corporation. 
/// 
/// The contents of this file are subject to the terms of the New BSD License. 
/// You may obtain a copy of the License at http://es5conformm.codeplex.com/license 
/// 
/// Alternatively the contents of this file may be used under the terms of the Microsoft Public License. 
/// You may obtain a copy of the License at http://www.microsoft.com/opensource/licenses.mspx#Ms-PL 

/*
local vars must not be visible outside with block
local functions must not be visible outside with block
local function expresssions should not be visible outside with block
local vars must shadow outer vars
local functions must shadow outer functions
local function expresssions must shadow outer function expressions
eval should use the appended object to the scope chain
*/

var testName = "catch introduces scope - block-local functions must shadow outer functions";

function testcase() {
  var o = {foo: function () { return 42;}};

  try {
    throw o;
  }
  catch (e) {
    function foo() {}
    if (foo() === undefined) {
      return true;
    }
  }
}

sth_addTest(testName, testcase);