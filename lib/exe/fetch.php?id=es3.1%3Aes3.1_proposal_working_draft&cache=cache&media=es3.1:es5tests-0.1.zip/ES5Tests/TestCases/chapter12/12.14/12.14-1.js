/// Copyright (c) Microsoft Corporation. 
/// 
/// The contents of this file are subject to the terms of the New BSD License. 
/// You may obtain a copy of the License at http://es5conformm.codeplex.com/license 
/// 
/// Alternatively the contents of this file may be used under the terms of the Microsoft Public License. 
/// You may obtain a copy of the License at http://www.microsoft.com/opensource/licenses.mspx#Ms-PL 

/*
local vars must not be visible outside with block
local functions must not be visible outside with block
local function expresssions should not be visible outside with block
local vars must shadow outer vars
local functions must shadow outer functions
local function expresssions must shadow outer function expressions
eval should use the appended object to the scope chain
*/

var testName = "catch introduces scope - block-local vars not visible outside";

function testcase() {
  try {
    throw new Error();
  }
  catch (e) {
    var foo = 42;
  }

  try {
    foo;
  }
  catch (e) {
    // actually, we need to have thrown a ReferenceError exception.
    // However, in JScript we have thrown a TypeError exception.
    // But that is a separate test.
    return true;
  }
}

sth_addTest(testName, testcase);