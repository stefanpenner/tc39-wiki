/// Copyright (c) Microsoft Corporation. 
/// 
/// The contents of this file are subject to the terms of the New BSD License. 
/// You may obtain a copy of the License at http://es5conformm.codeplex.com/license 
/// 
/// Alternatively the contents of this file may be used under the terms of the Microsoft Public License. 
/// You may obtain a copy of the License at http://www.microsoft.com/opensource/licenses.mspx#Ms-PL 

var testName = "eval - a function declaring a var named 'eval' throws EvalError in strict mode";

function testcase() {
  'use strict';

  try {
    eval('function foo() { var eval; }');
  }
  catch (e) {
    if (e instanceof EvalError) {
      return true;
    }
  }
}


sth_addTest(testName, testcase);