/// Copyright (c) Microsoft Corporation. 
/// 
/// The contents of this file are subject to the terms of the New BSD License. 
/// You may obtain a copy of the License at http://es5conformm.codeplex.com/license 
/// 
/// Alternatively the contents of this file may be used under the terms of the Microsoft Public License. 
/// You may obtain a copy of the License at http://www.microsoft.com/opensource/licenses.mspx#Ms-PL 

var testName = "Eval code in strict mode - cannot instantiate variable in calling context";

function testcase() {   
  eval("'use strict';var __10_4_2_3_1_s = 1");
  try
  {
    __10_4_2_3_1_s;
  }
  catch(e)
  {
    if(e instanceof ReferenceError)
      return true;
  }
}


sth_addTest(testName, testcase);