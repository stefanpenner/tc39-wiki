/// Copyright (c) Microsoft Corporation. 
/// 
/// The contents of this file are subject to the terms of the New BSD License. 
/// You may obtain a copy of the License at http://es5conformm.codeplex.com/license 
/// 
/// Alternatively the contents of this file may be used under the terms of the Microsoft Public License. 
/// You may obtain a copy of the License at http://www.microsoft.com/opensource/licenses.mspx#Ms-PL 

var testName = "Indirect call to eval has context set to global context (inside another eval)";

var __10_4_2_1_5 = "str";

function testcase() {
  var __10_4_2_1_5 = "str1";
  var r = eval("\
              var _eval = eval; \
              var __10_4_2_1_5 = \'str2\'; \
              _eval(\"\'str\' === __10_4_2_1_5 \") && \
              eval(\"\'str2\' === __10_4_2_1_5\")\
            ");   
  if(r == true)
    return true;
}

sth_addTest(testName, testcase);