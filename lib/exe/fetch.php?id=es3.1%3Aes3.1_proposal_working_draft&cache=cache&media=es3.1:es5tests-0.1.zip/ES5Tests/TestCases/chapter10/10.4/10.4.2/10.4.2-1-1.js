/// Copyright (c) Microsoft Corporation. 
/// 
/// The contents of this file are subject to the terms of the New BSD License. 
/// You may obtain a copy of the License at http://es5conformm.codeplex.com/license 
/// 
/// Alternatively the contents of this file may be used under the terms of the Microsoft Public License. 
/// You may obtain a copy of the License at http://www.microsoft.com/opensource/licenses.mspx#Ms-PL 

var testName = "Indirect call to eval has context set to global context";

var __10_4_2_1_1_1 = "str";
function testcase() {
  var _eval = eval;
  var __10_4_2_1_1_1 = "str1";
  if(_eval("\'str\' === __10_4_2_1_1_1") === true &&  // indirect eval
     eval("\'str1\' === __10_4_2_1_1_1") === true)   // direct eval
    return true;
}


sth_addTest(testName, testcase);