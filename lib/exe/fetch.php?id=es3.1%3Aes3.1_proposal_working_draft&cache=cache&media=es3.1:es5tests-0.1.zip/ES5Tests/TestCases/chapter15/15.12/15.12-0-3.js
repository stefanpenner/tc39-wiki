/// Copyright (c) Microsoft Corporation. 
/// 
/// The contents of this file are subject to the terms of the New BSD License. 
/// You may obtain a copy of the License at http://es5conformm.codeplex.com/license 
/// 
/// Alternatively the contents of this file may be used under the terms of the Microsoft Public License. 
/// You may obtain a copy of the License at http://www.microsoft.com/opensource/licenses.mspx#Ms-PL 

/*
This test should be run without any built-ins being added/augmented.
The name JSON must be bound to an object, and must not support [[Call]].
step 5 in 11.2.3 should throw a TypeError exception.
*/

var testName = "JSON must not support the [[Call]] method";

function testcase() {
  var o = JSON;

  try {
    var j = JSON();
  }
  catch (e) {
    if (e instanceof TypeError) {
      return true;
    }
  }
}

sth_addTest(testName, testcase);