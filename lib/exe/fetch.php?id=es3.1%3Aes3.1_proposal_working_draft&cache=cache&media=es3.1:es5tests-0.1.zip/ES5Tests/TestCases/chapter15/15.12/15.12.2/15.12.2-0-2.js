/// Copyright (c) Microsoft Corporation. 
/// 
/// The contents of this file are subject to the terms of the New BSD License. 
/// You may obtain a copy of the License at http://es5conformm.codeplex.com/license 
/// 
/// Alternatively the contents of this file may be used under the terms of the Microsoft Public License. 
/// You may obtain a copy of the License at http://www.microsoft.com/opensource/licenses.mspx#Ms-PL 

/*
This test should be run without any built-ins being added/augmented.
The name JSON must be bound to an object.

Section 15 says that every built-in Function object described in this
section � whether as a constructor, an ordinary function, or both � has
a length property whose value is an integer. Unless otherwise specified,
this value is equal to the largest number of named arguments shown in
the section headings for the function description, including optional
parameters.

This default applies to JSON.stringify, and it must exist as a function
taking 3 parameters.
*/

var testName = "JSON.stringify must exist as be a function taking 3 parameters";

function testcase() {
  var f = JSON.stringify;

  if (typeof(f) === "function" && f.length === 3) {
    return true;
  }
}

sth_addTest(testName, testcase);