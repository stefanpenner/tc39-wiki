/// Copyright (c) Microsoft Corporation. 
/// 
/// The contents of this file are subject to the terms of the New BSD License. 
/// You may obtain a copy of the License at http://es5conformm.codeplex.com/license 
/// 
/// Alternatively the contents of this file may be used under the terms of the Microsoft Public License. 
/// You may obtain a copy of the License at http://www.microsoft.com/opensource/licenses.mspx#Ms-PL 

/*
This test should be run without any built-ins being added/augmented.
The last paragraph in section 15 says "every other property described
in this section has the attribute {... [[Enumerable]] : false ...}
unless otherwise specified. This default applies to the properties on
JSON, and we should not be able to enumerate them.
*/

var testName = "JSON object's properties must be non enumerable";

function testcase() {
  var o = JSON;
  var i = 0;
  for (var p in o) {
    i++;
  }
    
  if (i === 0) {
    return true;
  }
}

sth_addTest(testName, testcase);