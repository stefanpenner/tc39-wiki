/// Copyright (c) Microsoft Corporation. 
/// 
/// The contents of this file are subject to the terms of the New BSD License. 
/// You may obtain a copy of the License at http://es5conformm.codeplex.com/license 
/// 
/// Alternatively the contents of this file may be used under the terms of the Microsoft Public License. 
/// You may obtain a copy of the License at http://www.microsoft.com/opensource/licenses.mspx#Ms-PL 

/*
This test should be run without any built-ins being added/augmented.
The initial value of [[Configurable]] on JSON is true. This means we
should be able to delete (8.6.2.5) the stringify and parse properties.
*/

var testName = "JSON.parse must be deletable (configurable)";

function testcase() {
  var o = JSON;
  var desc = Object.getOwnPropertyDescriptor(o, "parse");
  if (desc.configurable === true) {
    return true;
  }
}

sth_addTest(testName, testcase);