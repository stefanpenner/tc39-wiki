/// Copyright (c) Microsoft Corporation. 
/// 
/// The contents of this file are subject to the terms of the New BSD License. 
/// You may obtain a copy of the License at http://es5conformm.codeplex.com/license 
/// 
/// Alternatively the contents of this file may be used under the terms of the Microsoft Public License. 
/// You may obtain a copy of the License at http://www.microsoft.com/opensource/licenses.mspx#Ms-PL 

var testName = "Object.getPrototypeOf must exist as a function taking 1 parameter";

function testcase() {
  if (Object.getPrototypeOf.length === 1) {
    return true;
  }
}

function prereq() {
  return fnExists(Object.getPrototypeOf);
}

sth_addTest(testName, testcase, prereq);