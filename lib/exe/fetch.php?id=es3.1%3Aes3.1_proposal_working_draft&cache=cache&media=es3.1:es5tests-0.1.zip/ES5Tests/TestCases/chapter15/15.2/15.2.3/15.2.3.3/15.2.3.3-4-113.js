/// Copyright (c) Microsoft Corporation. 
/// 
/// The contents of this file are subject to the terms of the New BSD License. 
/// You may obtain a copy of the License at http://es5conformm.codeplex.com/license 
/// 
/// Alternatively the contents of this file may be used under the terms of the Microsoft Public License. 
/// You may obtain a copy of the License at http://www.microsoft.com/opensource/licenses.mspx#Ms-PL 

var testName = "Object.getOwnPropertyDescriptor returns data desc for functions on built-ins (Math.tan)";

function testcase() {
  var desc = Object.getOwnPropertyDescriptor(Math, "tan");
  if (desc.value === Math.tan &&
      desc.writable === true &&
      desc.enumerable === false &&
      desc.configurable === true) {
    return true;
  }
}

function prereq() {
  return fnExists(Object.getOwnPropertyDescriptor);
}

sth_addTest(testName, testcase, prereq);