/// Copyright (c) Microsoft Corporation. 
/// 
/// The contents of this file are subject to the terms of the New BSD License. 
/// You may obtain a copy of the License at http://es5conformm.codeplex.com/license 
/// 
/// Alternatively the contents of this file may be used under the terms of the Microsoft Public License. 
/// You may obtain a copy of the License at http://www.microsoft.com/opensource/licenses.mspx#Ms-PL 

/*
This test is actually testing the [[Delete]] internal method (8.12.8). Since the
language provides no way to directly exercise [[Delete]], the tests are placed here.
*/
var testName = "delete operator throws TypeError when deleting a non-configurable data property in strict mode";

function testcase() {
  'use strict';

  var o = {};
  var desc = { value : 1 }; // all other attributes default to false
  Object.defineProperty(o, "foo", desc);
  
  // Now, deleting o.foo should throw TypeError because [[Configurable]] on foo is false.
  try {
    delete o.foo;
  }
  catch (e) {
    if (e instanceof TypeError) {
      return true;
    }
  }
}

function prereq() {
  return fnExists(Object.defineProperty);
}

sth_addTest(testName, testcase, prereq);