/// Copyright (c) Microsoft Corporation. 
/// 
/// The contents of this file are subject to the terms of the New BSD License. 
/// You may obtain a copy of the License at http://es5conformm.codeplex.com/license 
/// 
/// Alternatively the contents of this file may be used under the terms of the Microsoft Public License. 
/// You may obtain a copy of the License at http://www.microsoft.com/opensource/licenses.mspx#Ms-PL 

/*
This test is actually testing the [[Delete]] internal method (8.12.8). Since the
language provides no way to directly exercise [[Delete]], the tests are placed here.
*/

var testName = "delete operator returns true when deleting a configurable accessor property";

function testcase() {
  var o = {};

  // define an accessor
  // dummy getter
  var getter = function () { return 1; }
  var desc = { get: getter, configurable: true };
  Object.defineProperty(o, "foo", desc);
    
  var d = delete o.foo;
  if (d === true && o.hasOwnProperty("foo") === false) {
    return true;
  }
}

function prereq() {
  return (fnExists(Object.defineProperty) && fnExists(Object.hasOwnProperty));
}

sth_addTest(testName, testcase, prereq);