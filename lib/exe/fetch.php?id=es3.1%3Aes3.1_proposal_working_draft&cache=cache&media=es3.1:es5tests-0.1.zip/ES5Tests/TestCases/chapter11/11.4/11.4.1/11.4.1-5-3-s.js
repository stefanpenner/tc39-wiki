/// Copyright (c) Microsoft Corporation. 
/// 
/// The contents of this file are subject to the terms of the New BSD License. 
/// You may obtain a copy of the License at http://es5conformm.codeplex.com/license 
/// 
/// Alternatively the contents of this file may be used under the terms of the Microsoft Public License. 
/// You may obtain a copy of the License at http://www.microsoft.com/opensource/licenses.mspx#Ms-PL 

/*
Refer NOTE in section 11.4.1, about the behaviour of the delete operator in strict mode.
*/

var testName = "delete operator throws ReferenceError when deleting a direct reference to a function name in strict mode";

function testcase() {
  'use strict';


  var foo = function(){};

  // Now, deleting 'foo' directly should fail throwing a ReferenceError
  // because 'foo' evaluates to a strict reference;
  try {
    delete foo;
  }
  catch (e) {
    if (e instanceof ReferenceError) {
      return true;
    }
  }
}

sth_addTest(testName, testcase);