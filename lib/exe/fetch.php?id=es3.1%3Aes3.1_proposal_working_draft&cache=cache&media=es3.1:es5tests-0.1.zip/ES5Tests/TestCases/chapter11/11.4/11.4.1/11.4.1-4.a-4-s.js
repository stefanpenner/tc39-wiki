/// Copyright (c) Microsoft Corporation. 
/// 
/// The contents of this file are subject to the terms of the New BSD License. 
/// You may obtain a copy of the License at http://es5conformm.codeplex.com/license 
/// 
/// Alternatively the contents of this file may be used under the terms of the Microsoft Public License. 
/// You may obtain a copy of the License at http://www.microsoft.com/opensource/licenses.mspx#Ms-PL 

/*
This test is actually testing the [[Delete]] internal method (8.12.8). Since the
language provides no way to directly exercise [[Delete]], the tests are placed here.
*/
var testName = "delete operator throws TypeError when when deleting a non-configurable data property in strict mode (Global.NaN)";

function testcase() {
  'use strict';
  
  // NaN (15.1.1.1) has [[Configurable]] set to false.
  try {
    delete this.NaN;
  }
  catch (e) {
    if (e instanceof TypeError) {
      return true;
    }
  }
}

sth_addTest(testName, testcase);