/// Copyright (c) Microsoft Corporation. 
/// 
/// The contents of this file are subject to the terms of the New BSD License. 
/// You may obtain a copy of the License at http://es5conformm.codeplex.com/license 
/// 
/// Alternatively the contents of this file may be used under the terms of the Microsoft Public License. 
/// You may obtain a copy of the License at http://www.microsoft.com/opensource/licenses.mspx#Ms-PL 

/*
This test is actually testing the [[Delete]] internal method (8.12.8). Since the
language provides no way to directly exercise [[Delete]], the tests are placed here.
*/
var testName = "delete operator returns false when deleting a non-configurable data property";

function testcase() {
  var o = {};
  var desc = { value : 1, configurable: false }; // all other attributes default to false
  Object.defineProperty(o, "foo", desc);
  
  // Now, deleting o.foo should fail because [[Configurable]] on foo is false.
  var d = delete o.foo;
  if (d === false && o.hasOwnProperty("foo") === true) {
    return true;
  }
}

function prereq() {
  return (fnExists(Object.defineProperty) && fnExists(Object.hasOwnProperty));
}

sth_addTest(testName, testcase, prereq);